import{s}from"./supabaseClient-C14Dpn6w.js";import{g as a}from"./guides-CwOT7Ft1.js";const{url:o,key:r}=a(),e=!(!o||!r),t=e?s:null;export{t as a,e as s};
