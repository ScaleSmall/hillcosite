import{s}from"./supabaseClient-QEPlwCAW.js";import{d as a}from"./guides-Bac91tsC.js";const{url:o,key:r}=a(),e=!(!o||!r),t=e?s:null;export{t as a,e as s};
